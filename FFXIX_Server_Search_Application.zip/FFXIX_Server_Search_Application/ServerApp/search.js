const router = require("express").Router();

const xiv = require("FFXIVModule");

const collection = require("../db/collection");
/* 
Should contain the logic for the searching 
by keyword and then getting details by id.

Should have an endpoint GET /search/<item>
Where item is related to the API chosen. 
This endpoint accepts a query parameter that 
is a keyword/ term which
This endpoint should use your custom node module 
(from the Midterm) to search by that keyword
This endpoint should respond with a proper 
status code and a JSON response that is an 
array of objects which only contains two 
keys: the id and displayText (text related to the search result). 
This endpoint should store the search 
keyword/term, a timestamp and the number of matching results*/

router.get("/item", async (req, res) => {
  try {
    //change to req.query
    const { item } = req.query;
    const itemList = await xiv.XIVAPI(item);
    const originalSearch = makeitemList(itemList);
    originalSearch["keyword"] = item;
    collection.add({
      keyword: item,
      "Time-Stamp": Date.now(),
      "Total-Results": itemList.Pagination.Results,
    });
    res.status(200).json(originalSearch);
  } catch (error) {
    res.status(500).json({ error: error.toString() });
  }
});

const makeitemList = (items) => {
  //initialize an empty array
  const searchList = [];
  //iterate through the list of item objects
  items.Results.forEach((element) => {
    //push each objects name and id as a new object to the array.
    searchList.push({ id: element.ID, name: element.Name });
  });
  //store the total search results into a variable
  const totalResults = items.Pagination.Results;
  //return an object with the returned list of results, number of results, and a timestamp
  return { searchList, totalResults, Date: Date.now() };
};

/*
Should have an endpoint POST /search/<item>
Where item is related to the API chosen. 
This endpoint accepts a POST body with an id
This endpoint should use your custom node module 
(from the Midterm) to get by id
This endpoint should respond with a proper 
status code and a JSON response that is a 
objects containing the details of the item */

//talk about API limitation by fetch by ID in DEMO
router.post("/item", async (req, res) => {
  try {
    //get the id and item keyword from the json body
    const { id, item } = req.body;
    // make call to API to get list
    const itemList = await xiv.XIVAPI(item);
    //perform a search on the list of returned items using the as ID for comparison among the list of objects and return the matched object
    res.json(getItem(id, itemList.Results));
  } catch (error) {
    res.status(500).json({ error: error.toString() });
  }
});

//method used to search through the list of item objects(items) and find the match based on the users selection from prompt(str)
const getItem = (id, items) => {
  //initialize an empty object
  let item = {};
  //iterate through the list of item objects
  items.forEach((element) => {
    //if a match for the users choice is found among the list of objects set item to that element
    if (element.ID !== undefined) {
      //compare object names
      if (element.ID === id) {
        item = element;
      }
    }
  });
  //create an object with the necesary details formatted for the user to view.
  const obj = {
    Name: item.Name,
    Level_Equip: item.LevelEquip,
    Level_Item: item.LevelItem,
    Item_Icon: item.Icon,
  };
  return obj;
};

module.exports = router;
