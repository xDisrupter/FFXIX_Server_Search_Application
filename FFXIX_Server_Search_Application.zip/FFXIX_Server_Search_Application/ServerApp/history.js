const router = require("express").Router();

const collection = require("../db/collection");

//GET /history/search
router.get("/search", (req, res) => {
  try {
    const results = collection.search();
    res.json(results);
  } catch (error) {
    res.status(500).json({ error: error.toString() });
  }
});

module.exports = router;
