const superagent = require("superagent");

//config file to hold the base url (& API key where applicable)
const config = require("./config.json");

const XIVAPI = async (term) => {
  try {
    const searchURL = `${config.url}`;
    //item search based on the recieved term
    const res = superagent.post(searchURL).send({
      indexes: "item,achievement,instantcontent",
      columns: "ID,Name,Icon,LevelItem,LevelEquip,ItemSearchCategory.Name",
      body: {
        query: {
          bool: {
            must: [
              {
                wildcard: {
                  NameCombined_en: `*${term}*`, //"*aiming*",
                },
              },
            ],
            filter: [
              {
                range: {
                  "ItemSearchCategory.ID": {
                    gt: "1",
                  },
                },
              },
              {
                range: {
                  LevelItem: {
                    gte: "1",
                  },
                },
              },
              {
                range: {
                  LevelItem: {
                    lte: "125",
                  },
                },
              },
            ],
          },
        },
        from: 0,
        size: 10,
        sort: [
          {
            LevelItem: "desc",
          },
        ],
      },
    });
    // return res.data.Results;
    return (await res).body;
  } catch (error) {
    return error;
  }
};

module.exports = {
  XIVAPI,
};
